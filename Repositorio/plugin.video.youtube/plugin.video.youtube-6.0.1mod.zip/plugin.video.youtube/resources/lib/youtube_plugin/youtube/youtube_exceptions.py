from .. import kodion

__author__ = 'bromix'


class LoginException(kodion.KodionException):
    pass


class YouTubeException(kodion.KodionException):
    pass
